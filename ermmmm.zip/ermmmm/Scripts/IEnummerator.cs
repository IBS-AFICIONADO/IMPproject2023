﻿internal interface IEnummerator
{
}